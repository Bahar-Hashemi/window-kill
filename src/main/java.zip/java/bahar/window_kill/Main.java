package bahar.window_kill;

import bahar.window_kill.view.GameLauncher;


public class Main {
    public static void main(String[] args) {
        new GameLauncher().initialize();
    }
}