package bahar.window_kill.model.entities;

public interface LootDropper {
    public int getLootCount();
    public Entity makeLoot();
}
