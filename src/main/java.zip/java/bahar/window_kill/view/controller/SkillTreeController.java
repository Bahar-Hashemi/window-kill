package bahar.window_kill.view.controller;

import bahar.window_kill.control.fazes.processors.abilities.AbilityWatch;
import bahar.window_kill.control.util.FileUtil;
import bahar.window_kill.model.data.Development;
import bahar.window_kill.model.data.Development.*;
import bahar.window_kill.view.MainStage;
import bahar.window_kill.view.PaneBuilder;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;

public class SkillTreeController {
    public VBox root;
    public VBox defenseBox, attackBox;
    private Development development;
    public Label xpLabel;

    public void initialize() {
        development = FileUtil.readDevelopment();
        makeData();
        MainStage.requestCenterOnScreen(root);
    }
    private void makeData() {
        xpLabel.setText("XP: " + development.getXp());
        defenseBox.getChildren().clear();
        attackBox.getChildren().clear();
        for (int i = 0; i < development.getDefenseStates().length; i++)
            defenseBox.getChildren().add(makeButton(development.getDefenseStates(), development.getDefenseWatch(), i));
        for (int i = 0; i < development.getAttackStates().length; i++)
            attackBox.getChildren().add(makeButton(development.getAttackStates(), development.getAttackWatch(), i));
    }
    private Button makeButton(State[] states, AbilityWatch[] abilityWatches, int index) {
        Button button = new Button("Writ of " + abilityWatches[index].getName());
        switch (states[index]) {
            case LOCKED:
                makeBorder("transparent", button);
                button.setText(button.getText() + "   " + abilityWatches[index].getPrice());
                button.setDisable(true);
                break;
            case UNLOCKED:
                makeBorder("transparent", button);
                button.setText(button.getText() + "   " + abilityWatches[index].getPrice());
                if (development.getXp() > abilityWatches[index].getPrice())
                    button.setOnAction(event -> {
                        development.bye(states, abilityWatches, index);
                        makeData();
                    });
                else
                    button.setDisable(true);
                break;
            case ACTIVE:
                makeBorder("yellow", button);
                button.setOnAction(event -> {
                    states[index] = State.BOUGHT;
                    makeData();
                });
                break;
            case BOUGHT:
                makeBorder("white", button);
                button.setOnAction(event -> {
                    development.activate(states, abilityWatches, index);
                    makeData();
                });
                break;
        }
        button.setPrefWidth(225);
        return button;
    }
    private void makeBorder(String color, Button button) {
        button.setStyle("-fx-border-color: " + color);
    }

    public void onBack(ActionEvent actionEvent) {
        FileUtil.saveDevelopment(development);
        MainStage.newScene();
        MainStage.add(PaneBuilder.MAIN_MENU_PANE.generatePane());
    }
}
