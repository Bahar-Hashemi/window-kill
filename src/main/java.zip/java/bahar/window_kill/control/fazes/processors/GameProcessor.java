package bahar.window_kill.control.fazes.processors;

abstract public class GameProcessor { //implement Observer Pattern
    abstract public void run();
}
